#!/bin/bash
java -Xms1024M -Xmx2048M -jar /Users/weiyi/Desktop/Minecraft Server/server.jar nogui
